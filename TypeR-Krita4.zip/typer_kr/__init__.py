"""TypeR for Krita - Paketinitialisierung.

Registriert den Docker bei Krita. Die eigentliche Logik liegt in typer_kr.py.
"""
from .typer_kr import register

register()
