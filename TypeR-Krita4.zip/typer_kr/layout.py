# -*- coding: utf-8 -*-
"""Reine Layout-Logik: Zeilenumbruch, gleichmäßiges Ausbalancieren,
Ellipsen-Einpassung (runde Sprechblasen) und Auto-Größe.

Bewusst ohne jede Qt-Abhängigkeit, damit sie isoliert getestet werden kann.
Textbreiten kommen über eine 'measurer(px)'-Funktion, die liefert:
    (width_of, space_w, line_h, ascent, descent)
"""

import math


# ---------------------------------------------------------------------------
# Fett-Runs: Text wird intern als Folge von (teiltext, fett)-Runs dargestellt,
# damit einzelne Wörter (oder Teile davon) fett sein können. Ein "Wort" trägt
# seinen vollen String (für die Breitenmessung) und seine Runs (zum Zeichnen).
# ---------------------------------------------------------------------------

class Word(object):
    __slots__ = ("text", "bold", "runs")

    def __init__(self, text, bold, runs):
        self.text = text      # voller Wortstring
        self.bold = bold      # True, wenn irgendein Zeichen fett ist
        self.runs = runs      # Liste [(teiltext, fett), ...]

    def __str__(self):
        return self.text


def make_runs(text, mask):
    """(text, mask) -> Liste [(teiltext, fett), ...] mit zusammengefassten
    gleich-fetten Abschnitten. mask: Liste bool gleicher Länge wie text."""
    runs = []
    for ch, b in zip(text, mask):
        b = bool(b)
        if runs and runs[-1][1] == b:
            runs[-1] = (runs[-1][0] + ch, b)
        else:
            runs.append((ch, b))
    return runs


def make_words(text, mask):
    """text an Leerzeichen in Wörter teilen; je Wort die Fett-Runs bewahren.
    Mehrfache Leerzeichen werden wie bei str.split() zusammengefasst."""
    words = []
    cur, curm = [], []
    for ch, b in zip(text, mask):
        if ch == " ":
            if cur:
                words.append(Word("".join(cur), any(curm),
                                  make_runs(cur, curm)))
                cur, curm = [], []
        else:
            cur.append(ch)
            curm.append(bool(b))
    if cur:
        words.append(Word("".join(cur), any(curm), make_runs(cur, curm)))
    return words


def split_paragraphs(text, mask):
    """(text, mask) an \\n in (absatztext, absatzmaske)-Paare teilen."""
    out = []
    s = 0
    for i, ch in enumerate(text):
        if ch == "\n":
            out.append((text[s:i], mask[s:i]))
            s = i + 1
    out.append((text[s:], mask[s:]))
    return out


def line_runs(words):
    """Wörter einer (umgebrochenen) Zeile zu einer Run-Liste verbinden;
    Wörter werden mit einem Leerzeichen getrennt (das Leerzeichen erbt die
    Fett-Eigenschaft des vorherigen Run-Endes), gleich-fette Runs verschmelzen."""
    runs = []

    def push(txt, b):
        if runs and runs[-1][1] == b:
            runs[-1] = (runs[-1][0] + txt, b)
        else:
            runs.append((txt, b))

    for wi, wd in enumerate(words):
        if wi > 0:
            push(" ", runs[-1][1] if runs else False)
        for (txt, b) in wd.runs:
            push(txt, b)
    return runs


def runs_text(runs):
    """Reiner Text einer Run-Liste."""
    return "".join(t for t, _ in runs)



def wrap_greedy(words, width_of, space_w, max_w):
    """Wörter gierig in Zeilen umbrechen, jede Zeile <= max_w."""
    lines = []
    cur = []
    cur_w = 0.0
    for w in words:
        ww = width_of(w)
        if not cur:
            cur = [w]
            cur_w = ww
        elif cur_w + space_w + ww <= max_w:
            cur.append(w)
            cur_w += space_w + ww
        else:
            lines.append(cur)
            cur = [w]
            cur_w = ww
    if cur:
        lines.append(cur)
    return lines


def balance_even(words, width_of, space_w, usable_w, k):
    """Wörter in genau k Zeilen aufteilen, sodass die Zeilen möglichst
    gleich lang sind (nahe der Durchschnittsbreite). Das vermeidet einzelne
    kurze Schlusszeilen ('Witwen') und ergibt eine ruhige, ovale Blockform.

    Minimiert die Summe der quadrierten Abweichung jeder Zeile von der
    Zielbreite per dynamischer Programmierung. O(k * n^2).
    """
    n = len(words)
    if n == 0:
        return []
    if k <= 1:
        return [list(words)]

    w = [width_of(x) for x in words]
    prefix = [0.0] * (n + 1)
    for i in range(n):
        prefix[i + 1] = prefix[i] + w[i]

    def line_width(i, j):  # Wörter i..j inkl.
        return (prefix[j + 1] - prefix[i]) + space_w * (j - i)

    # Zielbreite: durchschnittliche Zeilenbreite bei k Zeilen
    target = (prefix[n] + space_w * (n - k)) / k

    INF = float("inf")
    dp = [[INF] * (n + 1) for _ in range(k + 1)]
    nxt = [[-1] * (n + 1) for _ in range(k + 1)]
    dp[0][n] = 0.0

    for l in range(1, k + 1):
        for i in range(n - 1, -1, -1):
            best = INF
            bestj = -1
            for j in range(i, n):
                lw = line_width(i, j)
                over = lw > usable_w
                if over and j > i:
                    break
                rem = dp[l - 1][j + 1]
                if rem < INF:
                    # leichtes Gewicht: frühere Zeilen sollen voller sein, damit
                    # eine evtl. kürzere Zeile eher unten landet (üblicher Look).
                    weight = 1.0 + 0.04 * l
                    cost = (target - lw) ** 2 * weight + rem
                    if cost < best:
                        best = cost
                        bestj = j
                if over:  # einzelnes überlanges Wort: nicht erweiterbar
                    break
            dp[l][i] = best
            nxt[l][i] = bestj

    if dp[k][0] == INF:  # Notfall: gierig
        return wrap_greedy(words, width_of, space_w, usable_w)

    lines = []
    i = 0
    for l in range(k, 0, -1):
        j = nxt[l][i]
        if j < 0:
            break
        lines.append(words[i:j + 1])
        i = j + 1
    return lines


def _ellipse_line_widths(k, line_h, a, b):
    """Maximale Zeilenbreiten für k Zeilen in einer Ellipse (Halbachsen a, b),
    vertikal zentriert. Zeilen oben/unten sind schmaler."""
    mid = (k - 1) / 2.0
    out = []
    for i in range(k):
        dy = (i - mid) * line_h
        r = 1.0 - (dy / b) ** 2 if b > 0 else -1.0
        out.append(2.0 * a * math.sqrt(r) if r > 0 else 0.0)
    return out


def _wrap_schedule(words, width_of, space_w, widths):
    """Gierig umbrechen, wobei Zeile i höchstens widths[i] breit sein darf
    (überzählige Zeilen nutzen die schmalste/letzte Breite). Gibt None zurück,
    wenn ein einzelnes Wort selbst in seine Zeile nicht passt."""
    def maxw(i):
        if not widths:
            return 0.0
        return widths[i] if i < len(widths) else widths[-1]

    lines = []
    cur = []
    cur_w = 0.0
    for word in words:
        ww = width_of(word)
        if not cur:
            if ww > maxw(len(lines)):
                return None
            cur = [word]
            cur_w = ww
        elif cur_w + space_w + ww <= maxw(len(lines)):
            cur.append(word)
            cur_w += space_w + ww
        else:
            lines.append(cur)
            if ww > maxw(len(lines)):
                return None
            cur = [word]
            cur_w = ww
    if cur:
        lines.append(cur)
    return lines


def wrap_ellipse(words, width_of, space_w, a, b, line_h):
    """Wörter so umbrechen, dass sie in eine Ellipse (Halbachsen a, b) passen.
    Fixpunkt-Iteration über die Zeilenzahl, da die erlaubten Breiten von der
    (zentrierten) Zeilenzahl abhängen. Es wird nur ein in sich konsistentes
    Ergebnis zurückgegeben (jede Zeile passt zu der Zeilenzahl, mit der ihre
    Breiten berechnet wurden); sonst None -> der Aufrufer wählt eine kleinere
    Schrift."""
    if not words:
        return []
    init = wrap_greedy(words, width_of, space_w, 2.0 * a)
    k = max(1, len(init))
    for _ in range(12):
        widths = _ellipse_line_widths(k, line_h, a, b)
        res = _wrap_schedule(words, width_of, space_w, widths)
        if res is None:
            return None
        if len(res) == k:
            return res          # konsistent
        k = len(res)
        if k > 200:
            return None
    return None                 # nicht konvergiert -> kleinere Schrift


def fit_text(text, measurer, box_w, box_h, max_px, min_px, pad_frac,
             shape="rect", mask=None):
    """Größte Schriftgröße finden, bei der der umgebrochene Text passt.

    shape='rect'    : rechteckige Box, gleichmäßig ausbalancierte Zeilen.
                      Eingebettete Zeilenumbrüche (\\n) werden als feste
                      Umbrüche respektiert; jeder Absatz wird einzeln
                      ausbalanciert.
    shape='ellipse' : eingeschriebene Ellipse (runde Sprechblase); Zeilen
                      oben/unten werden schmaler. Feste Umbrüche werden hier
                      zu Leerzeichen (die Ellipsenform bestimmt den Umbruch).

    mask: optionale Liste bool gleicher Länge wie text – markiert fette Zeichen
    (für teilweise fetten Text). None -> nichts fett.

    Rückgabe: (font_px, lines, line_h, ascent, descent, fitted)
    'lines' ist eine Liste von Run-Listen ([(teiltext, fett), ...] je Zeile).
    """
    if mask is None:
        mask = [False] * len(text)

    usable_w = box_w * (1.0 - pad_frac)
    usable_h = box_h * (1.0 - pad_frac)

    if shape == "ellipse":
        # \n zählt hier als Leerzeichen
        flat = text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", " ")
        fmask = list(mask)
        # Längen bleiben gleich (1:1-Ersetzungen), Maske passt weiter
        words = make_words(flat, fmask)
        if not words:
            return None
        a = usable_w / 2.0
        b = usable_h / 2.0

        def fits(px):
            width_of, space_w, line_h, _asc, _desc = measurer(px)
            res = wrap_ellipse(words, width_of, space_w, a, b, line_h)
            if res is None:
                return None
            if len(res) * line_h > usable_h:
                return None
            return res
    else:
        norm = text.replace("\r\n", "\n").replace("\r", "\n")
        nmask = list(mask)
        paras = [make_words(pt, pm)
                 for (pt, pm) in split_paragraphs(norm, nmask)]
        if not any(paras):
            return None

        def fits(px):
            width_of, space_w, line_h, _asc, _desc = measurer(px)
            all_lines = []
            for words in paras:
                if not words:
                    all_lines.append([])           # bewusste Leerzeile
                    continue
                if max(width_of(w) for w in words) > usable_w:
                    return None
                all_lines.extend(wrap_greedy(words, width_of, space_w, usable_w))
            if len(all_lines) * line_h > usable_h:
                return None
            return all_lines

    lo = int(min_px)
    hi = int(max_px)
    best = None
    while lo <= hi:
        mid = (lo + hi) // 2
        if fits(mid) is not None:
            best = mid
            lo = mid + 1
        else:
            hi = mid - 1

    if best is None:
        best = int(min_px)
        fitted = False
    else:
        fitted = True

    width_of, space_w, line_h, ascent, descent = measurer(best)
    if shape == "ellipse":
        res = wrap_ellipse(words, width_of, space_w,
                           usable_w / 2.0, usable_h / 2.0, line_h)
        if res is None:
            res = wrap_greedy(words, width_of, space_w, usable_w)
        line_lists = res
    else:
        line_lists = []
        for words in paras:
            if not words:
                line_lists.append([])
                continue
            k = len(wrap_greedy(words, width_of, space_w, usable_w))
            line_lists.extend(balance_even(words, width_of, space_w, usable_w, k))
    lines = [line_runs(ws) for ws in line_lists]
    return best, lines, line_h, ascent, descent, fitted


def vertical_start(valign, box_y, box_h, pad_frac, k, line_h, ascent, descent):
    """Grundlinie der ERSTEN Zeile je nach vertikaler Ausrichtung.

    valign='middle' : Block um die Boxmitte zentriert (Standard).
    valign='top'    : Block oben in der Box (mit Innenabstand).
    valign='bottom' : Block unten in der Box (mit Innenabstand).
    """
    pad = box_h * pad_frac / 2.0
    if valign == "top":
        return box_y + pad + ascent
    if valign == "bottom":
        return box_y + box_h - pad - descent - (k - 1) * line_h
    cy = box_y + box_h / 2.0
    return cy - ((k - 1) * line_h + descent - ascent) / 2.0
