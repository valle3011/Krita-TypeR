# -*- coding: utf-8 -*-
"""Spracherkennung (Japanisch / Englisch) und Paarung von Quelle + Übersetzung.

Ohne Qt-Abhängigkeit, damit es isoliert getestet werden kann.
"""


def detect_lang(text):
    """Grobe Spracherkennung einer Zeile: 'ja', 'en' oder 'other'.

    Kana (Hiragana/Katakana) ist ein starkes Signal für Japanisch, da
    englischer Text nie Kana enthält. Eingebettete englische Namen in einer
    japanischen Zeile kippen die Erkennung daher nicht.
    """
    kana = kanji = en = 0
    for ch in text:
        o = ord(ch)
        if (0x3040 <= o <= 0x30FF      # Hiragana + Katakana
                or 0xFF66 <= o <= 0xFF9D):  # Halbbreiten-Katakana
            kana += 1
        elif 0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF:  # Kanji
            kanji += 1
        elif ch.isascii() and ch.isalpha():
            en += 1
    if kana > 0:
        return "ja"
    if kanji > 0 and (en == 0 or kanji >= en):
        return "ja"
    if en > 0:
        return "en"
    if kanji > 0:
        return "ja"
    return "other"


def pair_lines(lines):
    """Zeilen in (japanisch, englisch)-Paare gruppieren.

    Erkennt automatisch die Reihenfolge im Skript (erst Japanisch oder erst
    Englisch) anhand benachbarter Zeilen. Jede Einheit besteht aus einer
    'Kopf'-Zeile in der dominanten Quellsprache und allen folgenden Zeilen der
    anderen Sprache als zugehörige Übersetzung.

    Rückgabe: Liste von (ja, en); jeweils ggf. leerer String.
    Bei einsprachigen Skripten wird jede Zeile zu einer eigenen Einheit.
    """
    toks = [(detect_lang(t), t) for t in lines if t.strip() != ""]
    n = len(toks)
    if n == 0:
        return []

    # Reihenfolge bestimmen: kommt häufiger JA->EN oder EN->JA vor?
    ja_first = en_first = 0
    for (la, _ta), (lb, _tb) in zip(toks, toks[1:]):
        if la == "ja" and lb == "en":
            ja_first += 1
        elif la == "en" and lb == "ja":
            en_first += 1

    # Falls gar keine japanische Zeile existiert -> Englisch als Kopf,
    # damit einsprachige EN-Skripte jede Zeile als eigene Einheit bekommen.
    any_ja = any(l == "ja" for l, _ in toks)
    any_en = any(l == "en" for l, _ in toks)
    if not any_ja:
        head = "en"
    elif not any_en:
        head = "ja"
    else:
        head = "ja" if ja_first >= en_first else "en"

    pairs = []
    i = 0
    while i < n:
        lang, text = toks[i]
        if lang == head:
            head_text = text
            i += 1
            body = []
            while i < n and toks[i][0] != head:
                body.append(toks[i][1])
                i += 1
            body_text = " ".join(body)
            if head == "ja":
                pairs.append((head_text, body_text))
            else:
                pairs.append((body_text, head_text))
        else:
            # Zeile ohne vorangehenden Kopf -> auf die passende Seite stellen
            if lang == "ja":
                pairs.append((text, ""))
            else:
                pairs.append(("", text))
            i += 1
    return pairs


def unit_text(pair):
    """Welcher Text wird eingefügt: die Übersetzung (EN), sonst die Quelle (JA)."""
    ja, en = pair
    return en if en.strip() else ja
